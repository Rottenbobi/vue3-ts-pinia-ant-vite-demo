export interface ilogin{
    username:string;
    password:string;
    code:String;
    uuid:String;
} 