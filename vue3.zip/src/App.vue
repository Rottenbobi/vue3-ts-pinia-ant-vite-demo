<template>
 <router-view></router-view>
</template>
 
<script lang='ts' setup>
import { ref,reactive } from 'vue'

</script>
 
<style scoped>

</style>