import Login from '@/views/Login/index.vue'
export default {
    name: 'login',
    path: '/login',
    // component: () => import('@/views/Login/index.vue')
    component: Login
}